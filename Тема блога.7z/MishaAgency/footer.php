<!-- Footer Type-1 -->
      <footer class="footer footer-type-1 bg-dark">
        <div class="bottom-footer">
          <div class="container">
            <div class="row">
              <div class="col-sm-12 copyright text-center">
                <span>
                  © <?php echo date ('Y') ?> <?php bloginfo('name')?> - <?php bloginfo('description') ?> 
                </span>
              </div>

            </div>
          </div>
        </div>
      </footer> <!-- end footer -->

    </div> <!-- end content wrapper -->
  </div> <!-- end main wrapper -->


    <!-- <script type="text/javascript" src="<?php echo get_stylesheet_directory_uri() ?>/js/jquery.min.js"></script> -->

  <?php wp_footer() ?>
</body>
</html>