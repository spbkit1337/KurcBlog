<?php get_header(); ?>

    <div class="content-wrapper oh">

      <!-- Content -->
      <section class="section-wrap contact pt-mdm-60">
        <div class="container relative">
          <div class="text-center">
            <h1 class="heading underline-title uppercase">Пример страницы</h1>
          </div>
          <div class="row">

            <div class="col-sm-10 col-sm-offset-1">

              <?php the_content(); ?>

            </div>
          </div> <!-- end row -->

        </div> <!-- end container -->
      </section> <!-- end content -->

<?php get_footer(); ?>